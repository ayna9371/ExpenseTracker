```markdown
# Build Instructions — Expense Tracker (APK)

Overview
This project uses Expo + EAS (cloud builds) to produce Android APKs. The app id is com.expensetracker.app.

Mobile-only flow summary (no PC required)
1. Create a GitHub repository and add the project files (you can do this from a phone via GitHub website or GitHub mobile app).
2. Go to https://expo.dev and sign in with an Expo account (phone browser).
3. Connect your GitHub account under "Settings -> Account" (expo.dev) and grant access to the repository.
4. On expo.dev open the project (it will detect app.json) or manually create a new project linked to the repo+branch.
5. Start a Cloud Build from the expo.dev UI, choose Android -> APK build profile (production or preview).
6. Follow the web prompts to let Expo manage credentials (choose "Let Expo handle the credentials" if unsure).
7. Wait for the build to complete and download the APK link to your phone.

Detailed steps
- Create the repo (on GitHub mobile/site)
  1. Open github.com -> sign in.
  2. New -> Create repository -> Name: ExpenseTracker -> Public or Private -> Create repo.
  3. Add files: use "Add file -> Create new file" and paste each file content listed in the repo root or subfolders (create folders by entering path like src/utils/storage.ts).
  4. Add an /assets folder and upload simple placeholder images: icon.png, adaptive-icon.png, splash.png (these can be any small PNG so build won't fail).

- Link repo on Expo (expo.dev)
  1. Open https://expo.dev and sign in or sign up.
  2. Go to your account -> Projects -> New project from existing repo -> select GitHub -> select the ExpenseTracker repo and branch (main).
  3. Expo will read app.json and show the project.

- Start the build
  1. In the project page, choose "Builds" -> New build -> Android.
  2. Select profile: production (store) or preview (internal). Both can produce an APK if configured as shown in eas.json.
  3. When prompted for credentials, you can let Expo/EAS generate them automatically (recommended for first time).
  4. Tap "Start build".

- Download / install on Android phone
  1. When the build completes, expo.dev provides a download link.
  2. Open link on phone and download the APK.
  3. Install the APK (you may need to enable installing unknown apps in Android settings).
  4. Open app and test.

Troubleshooting tips
- If the build fails due to missing assets, upload placeholder PNGs into /assets as referenced in app.json.
- If expo.dev cannot find the repo or app.json, ensure files are committed in the repository root and you selected the correct branch.
- Use "Allow Expo to manage credentials" to avoid manual keystore steps on mobile.

If you'd like, I can:
- Produce a ready-to-upload ZIP file content (I can't host the zip here), or
- Provide a single-file paste (like a GitHub import JSON) — but creating the repo on GitHub web + paste files is the simplest mobile path.

```