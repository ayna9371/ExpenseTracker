import React from 'react';
import { SafeAreaView, StatusBar, Platform } from 'react-native';
import DemoScreen from './src/screens/DemoScreen';

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <StatusBar barStyle={Platform.OS === 'ios' ? 'dark-content' : 'light-content'} />
      <DemoScreen />
    </SafeAreaView>
  );
}