import AsyncStorage from '@react-native-async-storage/async-storage';

const EXPENSE_KEY = '@expenses_v1';

export async function getExpenses(): Promise<any[]> {
  try {
    const raw = await AsyncStorage.getItem(EXPENSE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.warn('getExpenses error', err);
    return [];
  }
}

export async function saveExpense(expense: any): Promise<any[]> {
  const list = await getExpenses();
  const next = [expense, ...list];
  await AsyncStorage.setItem(EXPENSE_KEY, JSON.stringify(next));
  return next;
}

export async function deleteExpense(id: string): Promise<any[]> {
  const list = await getExpenses();
  const next = list.filter((e: any) => e.id !== id);
  await AsyncStorage.setItem(EXPENSE_KEY, JSON.stringify(next));
  return next;
}

export async function clearAll(): Promise<void> {
  await AsyncStorage.removeItem(EXPENSE_KEY);
}