import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import XLSX from 'xlsx';

export async function generateAndShareExpenseWorkbook(data: any, filename = `Expense_Report_${new Date().toISOString().slice(0,10)}.xlsx`) {
  try {
    const wb = XLSX.utils.book_new();

    const addSheet = (name: string, rows: any[]) => {
      if (!rows || rows.length === 0) {
        const ws = XLSX.utils.aoa_to_sheet([['No records']]);
        XLSX.utils.book_append_sheet(wb, ws, name);
        return;
      }
      const ws = XLSX.utils.json_to_sheet(rows);
      XLSX.utils.book_append_sheet(wb, ws, name);
    };

    addSheet('Summary', data.summary);
    addSheet('Local Conveyance', data.localConveyance);
    addSheet('Outstation', data.outstation);
    addSheet('Other Claims', data.otherClaims);
    addSheet('BPE', data.bpe);
    addSheet('Other Claims Details', data.otherClaimsDetails);

    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
    const fileUri = `${FileSystem.cacheDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(fileUri, wbout, { encoding: FileSystem.EncodingType.Base64 });

    if (!(await Sharing.isAvailableAsync())) {
      return { success: true, uri: fileUri };
    }

    await Sharing.shareAsync(fileUri, { dialogTitle: 'Share Expense Report' });
    return { success: true, uri: fileUri };
  } catch (err) {
    console.error('Error generating workbook', err);
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}