import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, FlatList, Image, Alert, TouchableOpacity, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { generateAndShareExpenseWorkbook } from '../utils/exportExcel';
import * as Storage from '../utils/storage';

type Expense = {
  id: string;
  date: string;
  category: string;
  description: string;
  amount: number;
  distanceKm?: number;
  receipts?: string[];
};

const currencyFormat = (v: number) => `₹${v.toFixed(2)}`;

export default function DemoScreen() {
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState('Local Conveyance');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<string>('0');
  const [distanceKm, setDistanceKm] = useState<string>('0');
  const [receipts, setReceipts] = useState<string[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const list = await Storage.getExpenses();
      setExpenses(list);
    })();
  }, []);

  // Auto-calc for local conveyance: ₹4 per km
  useEffect(() => {
    if (category === 'Local Conveyance') {
      const km = parseFloat(distanceKm) || 0;
      setAmount((km * 4).toString());
    }
  }, [distanceKm, category]);

  const pickImage = async (mode: 'camera' | 'gallery') => {
    try {
      if (mode === 'camera') {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission required', 'Camera permission is required to take receipts');
          return;
        }
        const res = await ImagePicker.launchCameraAsync({ quality: 0.7 });
        // @ts-ignore
        if (!res.cancelled) setReceipts((p) => [...p, res.uri]);
      } else {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission required', 'Media library permission is required to pick receipts');
          return;
        }
        const res = await ImagePicker.launchImageLibraryAsync({ quality: 0.7, allowsMultipleSelection: true });
        // @ts-ignore
        if (!res.cancelled) {
          // @ts-ignore
          const uris = res.selected ? res.selected.map((s: any) => s.uri) : [res.uri];
          setReceipts((p) => [...p, ...uris]);
        }
      }
    } catch (err) {
      console.warn('Image pick error', err);
    }
  };

  const saveExpense = async () => {
    setLoading(true);
    try {
      const newExpense: Expense = {
        id: `${Date.now()}`,
        date,
        category,
        description,
        amount: parseFloat(amount) || 0,
        distanceKm: category === 'Local Conveyance' ? parseFloat(distanceKm) || 0 : undefined,
        receipts,
      };
      const updated = await Storage.saveExpense(newExpense);
      setExpenses(updated);
      setDescription('');
      setAmount('0');
      setDistanceKm('0');
      setReceipts([]);
      Alert.alert('Saved', 'Expense saved locally');
    } catch (err) {
      Alert.alert('Error', 'Could not save expense');
    } finally {
      setLoading(false);
    }
  };

  const removeExpense = async (id: string) => {
    Alert.alert('Delete', 'Delete this expense?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          const updated = await Storage.deleteExpense(id);
          setExpenses(updated);
        },
      },
    ]);
  };

  const onExport = async () => {
    const summary = [
      { Month: new Date().toLocaleString('default', { month: 'long', year: 'numeric' }), Total: expenses.reduce((s, e) => s + e.amount, 0) },
    ];
    const localConveyance = expenses.filter((e) => e.category === 'Local Conveyance').map((e) => ({ date: e.date, description: e.description, km: e.distanceKm || 0, amount: e.amount }));
    const outstation = expenses.filter((e) => e.category === 'Outstation').map((e) => ({ date: e.date, description: e.description, amount: e.amount }));
    const otherClaims = expenses.filter((e) => e.category !== 'Local Conveyance' && e.category !== 'Outstation').map((e) => ({ date: e.date, category: e.category, description: e.description, amount: e.amount }));
    const bpe: any[] = [];
    const otherClaimsDetails = otherClaims.map((c) => ({ ...c }));

    const res = await generateAndShareExpenseWorkbook({ summary, localConveyance, outstation, otherClaims, bpe, otherClaimsDetails });
    if (res.success) {
      Alert.alert('Exported', `Workbook saved: ${res.uri}`);
    } else {
      Alert.alert('Export failed', res.error || 'Unknown error');
    }
  };

  const renderItem = ({ item }: { item: Expense }) => (
    <View style={styles.item}>
      <View style={{ flex: 1 }}>
        <Text style={styles.itemTitle}>{item.category} — {currencyFormat(item.amount)}</Text>
        <Text style={styles.itemMeta}>{item.date} • {item.description}</Text>
        {item.distanceKm !== undefined ? <Text style={styles.itemMeta}>Distance: {item.distanceKm} km</Text> : null}
      </View>
      <View style={{ justifyContent: 'space-between' }}>
        <TouchableOpacity onPress={() => removeExpense(item.id)} style={styles.deleteBtn}>
          <Text style={{ color: '#fff' }}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, padding: 16, backgroundColor: '#f7f9fc' }}>
      <Text style={styles.title}>Expense Tracker — Demo</Text>

      <View style={styles.formRow}>
        <Text style={styles.label}>Date</Text>
        <TextInput value={date} onChangeText={setDate} style={styles.input} />
      </View>

      <View style={styles.formRow}>
        <Text style={styles.label}>Category</Text>
        <TextInput value={category} onChangeText={setCategory} style={styles.input} />
      </View>

      {category === 'Local Conveyance' && (
        <View style={styles.formRow}>
          <Text style={styles.label}>Distance (km)</Text>
          <TextInput value={distanceKm} keyboardType="numeric" onChangeText={setDistanceKm} style={styles.input} />
        </View>
      )}

      <View style={styles.formRow}>
        <Text style={styles.label}>Amount</Text>
        <TextInput value={amount} keyboardType="numeric" onChangeText={setAmount} style={styles.input} />
      </View>

      <View style={styles.formRow}>
        <Text style={styles.label}>Description</Text>
        <TextInput value={description} onChangeText={setDescription} style={styles.input} />
      </View>

      <View style={{ flexDirection: 'row', marginBottom: 8 }}>
        <Button title="Take Receipt" onPress={() => pickImage('camera')} />
        <View style={{ width: 8 }} />
        <Button title="Pick Receipt" onPress={() => pickImage('gallery')} />
      </View>

      <FlatList
        data={receipts}
        horizontal
        keyExtractor={(uri) => uri}
        renderItem={({ item }) => (
          <Image source={{ uri: item }} style={{ width: 80, height: 80, marginRight: 8, borderRadius: 6 }} />
        )}
        style={{ maxHeight: 96, marginBottom: 8 }}
      />

      <Button title={loading ? 'Saving...' : 'Save Expense'} onPress={saveExpense} disabled={loading} />

      <View style={{ height: 1, backgroundColor: '#ddd', marginVertical: 12 }} />

      <Text style={{ fontWeight: '700', marginBottom: 8 }}>Saved Expenses</Text>

      <FlatList data={expenses} keyExtractor={(i) => i.id} renderItem={renderItem} style={{ flex: 1 }} />

      <View style={{ marginVertical: 8 }}>
        <Button title="Export to Excel" onPress={onExport} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 20, fontWeight: '700', color: '#1976D2', marginBottom: 12 },
  formRow: { marginBottom: 8 },
  label: { fontSize: 12, color: '#444', marginBottom: 4 },
  input: { backgroundColor: '#fff', padding: 8, borderRadius: 6, borderWidth: 1, borderColor: '#eee' },
  item: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', borderRadius: 8, marginBottom: 8, alignItems: 'center' },
  itemTitle: { fontWeight: '700', marginBottom: 4 },
  itemMeta: { color: '#666', fontSize: 12 },
  deleteBtn: { backgroundColor: '#e53935', paddingVertical: 6, paddingHorizontal: 10, borderRadius: 6 },
});